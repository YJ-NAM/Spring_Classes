package com.khie.model;

import lombok.Data;

@Data
public class MemberDTO {

	private int num;
	private String memid;
	private String memname;
	private String pwd;
	private int age;
	private int mileage;
	private String job;
	private String addr;
	private String regdate;
	
}
